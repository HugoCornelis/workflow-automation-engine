package Scalar_object;
sub new { return bless \$_, 'Scalar_object'; }
1;
