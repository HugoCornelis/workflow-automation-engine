package Hash_object;
sub new { return bless {}, 'Hash_object'; }
1;
