package Array_object;
sub new { return bless [], 'Array_object'; }
1;
